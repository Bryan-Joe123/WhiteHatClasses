print("Welcome to the world of cryptography")

def main():
    print()
    print("Choose one option")
    choice = int(input("1. Encryption\n2. Decryption\nChoose(1,2): "))
    if choice == 1:
        encryption()
    elif choice == 2:
        decryption()
    else:
        print("Wrong Choice")


def encryption():
    msg = input("Enter the Text to Encrypt: ")
    key = int(input("Enter Key(1 - 94): "))
    print("Encryption Started...")
    encrypted_text = ""
    
    for x in range(len(msg)):
        temp = ord(msg[x])+key
        if temp > 126:
            temp = temp-127+32
        encrypted_text += chr(temp)
    print("Encrypted Test is",encrypted_text)

def decryption():
    msg = input("Enter the Text to Encrypt (It ca only be lowercase or upper case): ")
    key = int(input("Enter Key(1 - 94): "))
    print("Encryption Started...")
    decrypted_text = ""
    
    for x in range(len(msg)):
        temp = ord(msg[x])-key
        if temp < 32:
            temp = temp+127-32
        decrypted_text += chr(temp)
    print("Encrypted Test is",decrypted_text)
    pass
        
if __name__ == "__main__":
    main()
