#------------- Boilerplate Code Start------
import socket
from tkinter import *
from  threading import Thread
from PIL import ImageTk, Image

screen_width = None
screen_height = None

SERVER = None
PORT = None
IP_ADDRESS = None


canvas1 = None

player_name = None
name_entry = None
name_window = None

#------------- Boilerplate Code End------


def save_name():
    global SERVER
    global player_name
    global name_window
    global name_entry
    
    player_name = name_entry.get()
    name_entry.delete(0,END)
    name_window.destroy()
    SERVER.send(player_name.encode())
    pass



def askPlayerName():
    global player_name
    global name_entry
    global name_window
    global canvas1
    global screen_width
    global screen_height

    name_window  = Tk()
    name_window.title("Ludo Ladder")
    name_window.attributes('-fullscreen',True)


    screen_width = name_window.winfo_screenwidth()
    screen_height = name_window.winfo_screenheight()

    bg = ImageTk.PhotoImage(file = "./assets/background.png")

    canvas1 = Canvas( name_window, width = 500,height = 500)
    canvas1.pack(fill = "both", expand = True)
    # Display image
    canvas1.create_image( 0, 0, image = bg, anchor = "nw")
    canvas1.create_text( screen_width/2, screen_height/5, text = "Enter Name", font=("Chalkboard SE",100), fill="white")

    name_entry = Entry(name_window, width=15, justify='center', font=('Chalkboard SE', 50), bd=5, bg='white')
    name_entry.place(x = screen_width/2 - 220, y=screen_height/4 + 100)

    button = Button(name_window, text="Save", font=("Chalkboard SE", 30),width=15, command=save_name, height=2, bg="#80deea", bd=3)
    button.place(x = screen_width/2 - 130, y=screen_height/2 - 30)

    name_window.resizable(True, True)
    name_window.mainloop()


def setup():
    global SERVER
    global PORT
    global IP_ADDRESS

    PORT  = 5000
    IP_ADDRESS = '127.0.0.1'

    SERVER = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    SERVER.connect((IP_ADDRESS, PORT))


    
    askPlayerName()




setup()
